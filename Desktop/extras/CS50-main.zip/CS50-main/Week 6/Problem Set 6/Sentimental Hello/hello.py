print("hello, " + input("What is your name?\n"))
